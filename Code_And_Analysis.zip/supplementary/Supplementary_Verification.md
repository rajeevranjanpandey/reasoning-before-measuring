# Supplementary Verification

Budgeted Industrial Sensor Selection with Small Language Models: A Paired Evaluation with Thinking Disabled

Supplementary Verification

Budgeted Industrial Sensor Selection with Small Language Models: A Paired Evaluation with Thinking Disabled

S7. Dataset provenance and checksums

Harvard Dataverse dataset doi:10.7910/DVN/6C3JR1, version 1.0. The version-specific citation metadata, dsDescription field, explains the simulationRun column and states that generator seeds in the publisher training and testing partitions do not overlap. This does not establish that identically numbered runs across classes have identical seeds. The original generator seeds are unavailable.

Metadata endpoint: https://dataverse.harvard.edu/api/datasets/:persistentId/versions/1.0?persistentId=doi:10.7910/DVN/6C3JR1. Verified 9 October 2026. All four recorded MD5 values match this version’s publisher file checksums; local SHA-256 values are listed below.

TEP_FaultFree_Testing.RData

Publisher and recorded local MD5: 38ad9810fc871026157086ae2c2f0ee9

Local SHA-256: 4f45afafa469793eeb7203fb9ed10ed0b1724c73c9c95537f15a0889ade0ebd4

TEP_FaultFree_Training.RData

Publisher and recorded local MD5: ec126484534331f85001d8c4ebce6d17

Local SHA-256: 12d1055b852763fac09ef36bd7c9612a800c8bf7b6f75f344d12119206f9e940

TEP_Faulty_Testing.RData

Publisher and recorded local MD5: 556bdb64c83021bc0c5f92e427753565

Local SHA-256: c2f1aabc77498efda4d5f9ad81ecc829e2fcd98752b84cf5b2a06558cabacc36

TEP_Faulty_Training.RData

Publisher and recorded local MD5: c5f594d54c47e620ff877feb58407fda

Local SHA-256: 058df8bd90c5f575f44d2f6085bdd3bc3662e3e9cc25a50e34af42be3748952b

S8. Experimental software and model artefacts

llama-cpp-python: 0.3.19. The corresponding versioned software records are cited in the main manuscript.

scikit-learn: 1.9.1. The corresponding versioned software records are cited in the main manuscript.

matplotlib: 3.11.2. The corresponding versioned software records are cited in the main manuscript.

pyreadr: 0.5.6. The corresponding versioned software records are cited in the main manuscript.

Runtime: Python 3.12.14; Apple M2, 8 GiB unified memory, macOS 26.6.2, Metal, four CPU threads, 4,096-token context. Experimental inference uses Q8_0 weights, thinking disabled, temperature 0.7, top-p 0.8, top-k 20 and a 32-token response cap, as specified in the frozen methods.

Qwen3-1.7B: revision 90862c4b9d2787eaed51d12237eafdfe7c5f6077

Granite 3.3 2B Instruct: revision 7cdf86ccd1f1bb3491c9b7017b033f2e51367397

Model file: granite-3.3-2b-instruct-Q8_0.gguf

SHA-256: 39068a5bcb15f10487a49426d617b1b0f38a624d7dbdefe5ff6f26de82d97039

Model file: Qwen3-1.7B-Q8_0.gguf

SHA-256: 061b54daade076b5d3362dac252678d17da8c68f07560be70818cace6590cb1a

S9. Episode identity and tool agreement audit

pilot: 2520 Qwen episodes; 1260 raw/assisted pairs; zero acquisition-path or diagnostic-prediction mismatches. Every path follows ascending legal sensor IDs. Prompt text and runtime are not claimed to be identical.

confirmation: 18900 Qwen episodes; 9450 raw/assisted pairs; zero acquisition-path or diagnostic-prediction mismatches. Every path follows ascending legal sensor IDs. Prompt text and runtime are not claimed to be identical.

closed_loop: 4200 Qwen episodes; 2100 raw/assisted pairs; zero acquisition-path or diagnostic-prediction mismatches. Every path follows ascending legal sensor IDs. Prompt text and runtime are not claimed to be identical.

The 52,440 analysed model/control episodes comprise 5,040 pilot, 37,800 confirmation, 8,400 selected-predictor and 1,200 matched interface-control episodes. Excluded development logs contain 80 final checks (40 per model), plus 140 archived earlier parser/runtime-check records; none contributes to the reported diagnostic endpoints.

The 35,700 confirmation reference records are 34 policy–budget–seed combinations × 1,050 snapshots: 24 deterministic policy–budget combinations, nine random policy–budget–seed combinations and one full-sensor reference. Machine-readable combination counts accompany the review deposit.

Pilot Granite agreement: 31/3,780 decisions = 0.8201%. Qwen: 1,260/3,780 = 33.3333%. Agreement uses the highest rounded prompt score, with lowest sensor ID breaking ties. Uniform choice over legal remaining IDs gives 1/41, 1/40 and 1/39 agreement at the three steps, or 2.5010% on average. This is a descriptive benchmark, not a significance test based on independent decisions.

S10. Post hoc exact family sign-flip check

For each of the four frozen final-study contrasts, correctness is averaged within each of the 20 run families over all 21 classes and five recorded model seeds; deterministic reference correctness is broadcast over seeds. The paired differences are represented by integer numerators out of 105. Enumerating all 2^20 = 1,048,576 family sign assignments gives the fraction whose absolute sum is at least the observed absolute sum. The table gives two-sided exact p-values and Bonferroni adjustments over four contrasts.

Conditional on fitted predictor and recorded seeds. Family-sign exchangeability under a null is an assumption, not established by the evaluation. Not a new primary analysis; does not include seed or predictor refitting uncertainty. The re-analysis is post hoc and descriptive. It does not alter the primary contrasts, bootstrap intervals, pilot criterion or study decisions.

| Contrast | Difference (points) | Exact p | Adjusted p |
| qwen assisted minus forward | -3.8095 | 0.034301758 | 0.13720703 |
| qwen assisted minus rounded tool | -8.0952 | 0.00088500977 | 0.0035400391 |
| granite assisted minus forward | -10.5238 | 7.6293945e-06 | 3.0517578e-05 |
| granite assisted minus rounded tool | -14.8095 | 5.7220459e-06 | 2.2888184e-05 |

With four-contrast adjustment, the Qwen-minus-forward check remains inconclusive (p = 0.1372). Under the sign-flip assumptions, the adjusted assisted-minus-tool values are 0.003540 for Qwen and 0.00002289 for Granite. These conditional post hoc checks supplement rather than certify finite-cluster bootstrap coverage.

