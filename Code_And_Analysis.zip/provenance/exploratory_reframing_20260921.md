# Exploratory manuscript revision

At the author request, the manuscript was reframed after observing pilot outcomes as an exploratory empirical study. The original primary contrasts, bootstrap procedure, multiplicity allocation, three-point target, decision and all experiment records are unchanged. No new confirmatory status, causal result or favorable result is asserted. The title, abstract, introduction, discussion and conclusion now distinguish empirical observations from hypotheses for future work.

Figure 3 replaces the log-scale accuracy/time scatter with two linear-scale runtime panels. Median and 95th percentile are retained exactly from recorded summaries. Repeated-model seconds and reference milliseconds are separated; checkpoint and fixed-plan timing scopes are labeled. Segments are not uncertainty intervals. This is a presentation change, not a new timing experiment.
